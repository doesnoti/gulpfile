<?php require_once 'header.php'; ?>

<h1>Test</h1>
	
<?php require_once 'footer.php'; ?>