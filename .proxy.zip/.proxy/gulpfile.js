const {src, dest} = require('gulp'),
	gulp 				= require('gulp'),
	autoPref			= require('gulp-autoprefixer'),
	cleanCss			= require('gulp-clean-css'),
	rename			= require('gulp-rename'),
	browserSync 	= require('browser-sync').create(),
	uglify			= require('gulp-uglify-es').default


function browsersync(){
	browserSync.init({
		proxy: 'blackout.les',
		notify: false
	})
}

function style(){
	return src('css/style.css')
		.pipe(
			rename({
				extname: '.min.css'
			})
		)
		.pipe(cleanCss())
		.pipe(
			autoPref({
				grid: true,
				overrideBrowserslist: ['last 5 versions'],
				cascade: true
			})
		)
		.pipe(dest('css/'))
		.pipe(browserSync.stream())
}

function script(){
	return src('js/script.js')
		.pipe(
			rename({
				extname: '.min.js'
			})
		)
		.pipe(uglify())
		.pipe(dest('js/'))
		.pipe(browserSync.stream())
}

function watchFiles(){
	gulp.watch(['css/**/*.css', '!css/style.min.css'], style)
	gulp.watch(['**/*.php']).on('change', browserSync.reload)
	gulp.watch(['js/script.js'], script)
}


const watch = gulp.series(style, script,  gulp.parallel(watchFiles, browsersync))

exports.scripts	= script
exports.style		= style
exports.watch 		= watch
exports.default 	= watch